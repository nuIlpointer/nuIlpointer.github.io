const now = require("performance-now")
const fs = require("fs");
const rl = require("readline").createInterface(process.stdin,process.stdout);


const twconf = require("./twconf.json")
const twitter = require("twitter")
const tw = new twitter(twconf);
const ids = fs.readFileSync("follower.txt", "utf8")
require('date-utils');
const rq = require("request")

var totaltweets = 0
var twtime = new Date()
var otwtime = new Date()
var otwhh = 0
var otwmi = 0
var otwss = 0

console.log("Welcome to nuilClient!\nnote: This client is currently in alpha version. \nsee more details: https://nuilpointer.github.io/nuiltwitterclient/ \n初回起動された方へお願い:初回セットアップの際にフォロワー一覧を生成する際に @jack氏を指定する設定になっています。必ず/fwを実行して生成しなおしてください。")

rl.on("line",function(str){
  var start = now()
  if(str.match(/\//)) {
    if(str.match("/clear")) {
      process.stdout.write('\033c');
    }
    if(str == "/fw") {
      tw.get("followers/ids", {screen_name: "nuilpointer"}, function(err, users) {
        fs.writeFile("follower.txt", users.ids, function(err) {
          if(!err) {
            console.log("success to renew follower")
          } else {
            console.log("error! :" + err)
          }
        })
      })
    }
    if(str.match("/exit")) {
      process.exit()
    }
    if(str == "/f") {
      if(global.TwId != null) {
        fi = String(global.TwId)
        tw.post("favorites/create", {id: fi, include_entities: true}, function(err) {
          if(!err) {
            console.log("favorite tweet!")
          } else {
            console.log("err! : " + JSON.parse(err))
          }
        })
      } else {
        console.log("favorite failed! Tweet ID is not defined!")
      }
    }

    //めんどくさいからRTも使いまわし
    if(str == "/r") {
      if(global.TwId != null) {
        fi = String(global.TwId)
        tw.post("statuses/retweet", {id: fi}, function(err) {
          if(!err) {
            console.log("retweet!")
          } else {
            console.log("err! : " + JSON.parse(err))
          }
        })
      } else {
        console.log("retweet failed! Tweet ID is not defined!")
      }
    }

    //両方ともやるやつ
    if(str == "/m") {
      if(global.TwId != null) {
        fi = String(global.TwId)
        tw.post("favorites/create", {id: fi, include_entities: true}, function(err) {
          if(!err) {
            console.log("favorite tweet!")
          } else {
            console.log("err! : " + JSON.parse(err))
          }
        })
        tw.post("statuses/retweet", {id: fi}, function(err) {
          if(!err) {
            console.log("retweet!")
          } else {
            console.log("err! : " + JSON.parse(err))
          }
        })
      } else {
        console.log("favorite failed! Tweet ID is not defined!")
      }
    }
  } else {
    tw.post("statuses/update",{status:str},function(err,tweet,response) {
      if (!err) {
        var end = now()

        //時間計測
        var id = Number(tweet.id_str)
        id = ((id/4194304)+1288834974657);
        id = parseInt(id,10);
        var u3 = Number(String(id).substr(-3,3))
        id -= u3

        var td = new Date(id);
        var Time = td.toFormat("YYYY/MM/DD HH24:MI:SS") + "." + u3
        console.log(Time)
        //ツイートに成功した時間を登録、変換
        twtime = new Date()
        //見れるように変換
        twhh = twtime.toFormat("HH24")
        twmi = twtime.toFormat("MI")
        twss = twtime.toFormat("SS")
        //時間計算 さっさと書き直せ
        if(twss >= otwss) {
          ss = twss - otwss

          //一桁の場合に"0"を追加
          if(ss < 10) { ss = "0" + ss }
        } else {
          ss = twss - otwss + 60
        }

        if(twmi >= otwmi) {
          mi = twmi - otwmi
          if(mi < 10) {
            mi = "0" + mi
          }
        } else {
          mi = twmi - otwmi + 60
        }
        if(twhh >= otwhh) {
          hh = twhh - otwhh
          if(hh < 10) {
            hh = "0" + hh
          }
        } else {
          hh = twhh - otwhh + 24
        }

        //クライアントを起動してからのツイート数を+1
        totaltweets = totaltweets + 1

        //コンソールに成功と時間を出力
        console.log("Post success. Total Tweets: " + totaltweets + "\ndifference: " + hh + ":" + mi + ":" + ss + "\nAPI delay: " + (end-start).toFixed(2) + "ms\n")

        //今回のツイートの時間を「一つ前のツイートの時間」として登録
        otwtime = new Date()
        otwhh = otwtime.toFormat("HH24")
        otwmi = otwtime.toFormat("MI")
        otwss = otwtime.toFormat("SS")
      } else {
        //errが存在する場合
        console.log("Error! post failed.\n" + err)
      }
    });
  }
});

tw.stream("statuses/filter", {follow: ids}, function(stream) {
  stream.on("data", function(twi) {
    //TLのユーザーがパズるとめちゃくちゃそのツイートが表示されるのでRTを消す(ここらへんいじったら大丈夫なんだろうけどめんどいので却下)
    if(!twi.text.match("RT @")) {
      //それなりに整形して画面に出力
      console.log(twi.user.name +"(@" + twi.user.screen_name + "):"+twi.text + "\n")
      global.TwId = twi.id_str
    }
  })
})
